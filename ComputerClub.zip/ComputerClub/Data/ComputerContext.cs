﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace ComputerClub
{
    public partial class ComputerContext : DbContext
    {
        public ComputerContext()
        {
        }

        public ComputerContext(DbContextOptions<ComputerContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Client> Clients { get; set; }
        public virtual DbSet<Computer> Computers { get; set; }
        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Post> Posts { get; set; }
        public virtual DbSet<Rent> Rents { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Cyrillic_General_CI_AS");

            modelBuilder.Entity<Client>(entity =>
            {
                entity.HasKey(e => e.Idclient)
                    .HasName("PK__Client__CDECAB2C3258885B");

                entity.HasIndex(e => e.Telephon, "QU_Telephon")
                    .IsUnique();

                entity.Property(e => e.Idclient).HasColumnName("IDClient");

                entity.Property(e => e.Birthday).HasColumnType("date");

                entity.Property(e => e.Email)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Fio)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("FIO");

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Note).IsUnicode(false);

                entity.Property(e => e.Telephon)
                    .IsRequired()
                    .HasMaxLength(11)
                    .IsUnicode(false)
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<Computer>(entity =>
            {
                entity.HasKey(e => e.Idcomputer)
                    .HasName("PK__Computer__07796103A3F7F40D");

                entity.Property(e => e.Idcomputer).HasColumnName("IDComputer");

                entity.Property(e => e.Note).IsUnicode(false);

                entity.Property(e => e.Os)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("OS");

                entity.Property(e => e.Price).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.Type)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.Idemp)
                    .HasName("PK__Employee__9229F839813760C1");

                entity.HasIndex(e => e.PassportNumber, "UQ_Number")
                    .IsUnique();

                entity.HasIndex(e => e.PassportSeria, "UQ_Seria")
                    .IsUnique();

                entity.HasIndex(e => e.Telephon, "UQ_Tel")
                    .IsUnique();

                entity.Property(e => e.Idemp).HasColumnName("IDEmp");

                entity.Property(e => e.Adress)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Birthday).HasColumnType("date");

                entity.Property(e => e.Fio)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("FIO");

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Idpost).HasColumnName("IDPost");

                entity.Property(e => e.Login)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Note).IsUnicode(false);

                entity.Property(e => e.PassportNumber)
                    .IsRequired()
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.PassportSeria)
                    .IsRequired()
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Password)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Telephon)
                    .IsRequired()
                    .HasMaxLength(11)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.HasOne(d => d.IdpostNavigation)
                    .WithMany(p => p.Employees)
                    .HasForeignKey(d => d.Idpost)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Employees__IDPos__4865BE2A");
            });

            modelBuilder.Entity<Post>(entity =>
            {
                entity.HasKey(e => e.Idpost)
                    .HasName("PK__Post__8B0115BDBF3476C1");

                entity.Property(e => e.Idpost).HasColumnName("IDPost");

                entity.Property(e => e.Note).IsUnicode(false);

                entity.Property(e => e.Postname)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Responsibilities).IsUnicode(false);

                entity.Property(e => e.Salary).HasColumnType("money");
            });

            modelBuilder.Entity<Rent>(entity =>
            {
                entity.HasKey(e => e.Idrent)
                    .HasName("PK__Rents__A0EFC800DE3C9F64");

                entity.Property(e => e.Idrent).HasColumnName("IDRent");

                entity.Property(e => e.DateTimeEnd).HasColumnType("datetime");

                entity.Property(e => e.DateTimeStart).HasColumnType("datetime");

                entity.Property(e => e.Idcomputer).HasColumnName("IDComputer");

                entity.Property(e => e.Idemp).HasColumnName("IDEmp");

                entity.Property(e => e.Note).IsUnicode(false);

                entity.Property(e => e.Price).HasColumnType("smallmoney");

                entity.Property(e => e.Renter)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdcomputerNavigation)
                    .WithMany(p => p.Rents)
                    .HasForeignKey(d => d.Idcomputer)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Rents__IDCompute__4F12BBB9");

                entity.HasOne(d => d.IdempNavigation)
                    .WithMany(p => p.Rents)
                    .HasForeignKey(d => d.Idemp)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Rents__IDEmp__4D2A7347");

                entity.HasOne(d => d.RentClientNavigation)
                    .WithMany(p => p.Rents)
                    .HasForeignKey(d => d.RentClient)
                    .HasConstraintName("FK__Rents__RentClien__4E1E9780");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
