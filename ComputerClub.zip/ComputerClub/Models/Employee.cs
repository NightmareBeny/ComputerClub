﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace ComputerClub
{
    public partial class Employee
    {
        public Employee()
        {
            Rents = new HashSet<Rent>();
        }

        public int Idemp { get; set; }

        [Display(Name = "Логин")]
        [StringLength(20)]
        //[Required(ErrorMessage = "Введите логин")]
        public string Login { get; set; }

        [Display(Name = "Пароль")]
        [StringLength(10, MinimumLength = 3)]
        //[Required(ErrorMessage = "Введите пароль")]
        public string Password { get; set; }

        [Display(Name = "Должность")]
        public int Idpost { get; set; }

        [Display(Name = "ФИО сотрудника")]
        [StringLength(50)]
        [Required(ErrorMessage = "Введите ФИО сотрудника")]
        public string Fio { get; set; }

        [Display(Name = "Пол")]
        [Required(ErrorMessage = "Укажите пол")]
        public string Gender { get; set; }

        [Display(Name = "Дата рождения")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd.MM.yyyy}")]
        [Required(ErrorMessage = "Введите дату рождения")]
        public DateTime Birthday { get; set; }

        [Display(Name = "Серия паспорта")]
        [StringLength(4)]
        [Required(ErrorMessage = "Укажите серию паспорта")]
        public string PassportSeria { get; set; }

        [Display(Name = "Номер паспорта")]
        [StringLength(6)]
        [Required(ErrorMessage = "Укажите номер паспорта")]
        public string PassportNumber { get; set; }

        [Display(Name = "Адрес проживания")]
        [Required(ErrorMessage = "Укажите адрес проживания")]
        public string Adress { get; set; }

        [Display(Name = "Телефон")]
        [DataType(DataType.PhoneNumber)]
        [StringLength(11)]
        [Required(ErrorMessage = "Укажите номер телефона")]
        public string Telephon { get; set; }

        [Display(Name = "Примечание")]
        [DataType(DataType.MultilineText)]
        public string Note { get; set; }

        [Display(Name ="Должность")]
        public virtual Post IdpostNavigation { get; set; }
        public virtual ICollection<Rent> Rents { get; set; }
    }
}
