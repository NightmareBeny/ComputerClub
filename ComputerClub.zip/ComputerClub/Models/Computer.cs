﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace ComputerClub
{
    public partial class Computer
    {
        public Computer()
        {
            Rents = new HashSet<Rent>();
        }

        [Display(Name ="Номер компьютера")]
        public int Idcomputer { get; set; }

        [Display(Name ="Тип ОС")]
        [StringLength(10)]
        public string Os { get; set; }

        [Display(Name = "Тип компьютера")]
        [StringLength(10)]
        public string Type { get; set; }

        [Display(Name = "Стоимость аренды, руб/час")]
        [DataType(DataType.Currency)]
        [Required(ErrorMessage ="Укажите стоимость аренды")]
        public decimal Price { get; set; }

        [Display(Name = "Свободен")]
        public bool IsFree { get; set; } = true;

        [Display(Name = "Примечание")]
        [DataType(DataType.MultilineText)]
        public string Note { get; set; }

        public virtual ICollection<Rent> Rents { get; set; }
    }
}
