﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace ComputerClub
{
    public partial class Rent
    {
        public int Idrent { get; set; }

        [Display(Name = "ФИО сотрудника оформившего заявку")]
        public int Idemp { get; set; }
        public int? RentClient { get; set; }

        [Display(Name = "Номер компьютера")]
        public int Idcomputer { get; set; }

        [Display(Name ="ФИО арендатора")]
        [StringLength(50)]
        //[Required(ErrorMessage = "Укажите ФИО арендатора")]
        public string Renter { get; set; }

        [Display(Name = "Дата и время начала аренды")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:dd.MM.yyyy-HH:mm}")]
        [Required(ErrorMessage = "Введите дату и время начала аренды")]
        public DateTime DateTimeStart { get; set; } = DateTime.Today.AddHours(DateTime.Now.Hour).AddMinutes(DateTime.Now.Minute);

        [Display(Name = "Дата и время окончания аренды")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:dd.MM.yyyy-HH:mm}")]
        [Required(ErrorMessage = "Введите дату и время окончания аренды")]
        public DateTime DateTimeEnd { get; set; } = DateTime.Today.AddHours(DateTime.Now.Hour).AddMinutes(DateTime.Now.Minute);

        [Display(Name = "Стоимость аренды, руб")]
        [DataType(DataType.Currency)]
        [Required(ErrorMessage = "Укажите стоимость аренды")]
        public decimal Price { get; set; }

        [Display(Name = "Примечание")]
        [DataType(DataType.MultilineText)]
        public string Note { get; set; }

        [Display(Name ="Номер компьютера")]
        public virtual Computer IdcomputerNavigation { get; set; }

        [Display(Name = "ФИО сотрудника оформившего заявку")]
        public virtual Employee IdempNavigation { get; set; }

        [Display(Name = "ФИО арендатора-клиента")]
        public virtual Client RentClientNavigation { get; set; }
    }
}
