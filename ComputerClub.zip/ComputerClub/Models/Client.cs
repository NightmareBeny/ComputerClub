﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace ComputerClub
{
    public partial class Client
    {
        public Client()
        {
            Rents = new HashSet<Rent>();
        }

        public int Idclient { get; set; }

        [Display(Name = "ФИО клиента")]
        [StringLength(50)]
        [Required(ErrorMessage = "Укажите ФИО клиента")]
        public string Fio { get; set; }

        [Display(Name = "Пол")]
        [Required(ErrorMessage = "Укажите пол")]
        public string Gender { get; set; }

        [Display(Name = "Дата рождения")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd.MM.yyyy}")]
        [Required(ErrorMessage = "Укажите дату рождения клиента")]
        public DateTime Birthday { get; set; }

        [Display(Name = "Телефон")]
        [DataType(DataType.PhoneNumber)]
        [StringLength(11)]
        [Required(ErrorMessage = "Укажите номер телефона")]
        public string Telephon { get; set; }

        [Display(Name = "E-mail")]
        [DataType(DataType.EmailAddress)]
        [StringLength(30)]
        public string Email { get; set; }

        [Display(Name ="Скидка, %")]
        public float? Discount { get; set; }

        [Display(Name = "Примечание")]
        [DataType(DataType.MultilineText)]
        public string Note { get; set; }

        public virtual ICollection<Rent> Rents { get; set; }
    }
}
