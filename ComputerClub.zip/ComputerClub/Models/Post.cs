﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace ComputerClub
{
    public partial class Post
    {
        public Post()
        {
            Employees = new HashSet<Employee>();
        }

        public int Idpost { get; set; }

        [Display(Name = "Название должности")]
        [StringLength(30)]
        [Required(ErrorMessage = "Укажите название должности")]
        public string Postname { get; set; }

        [Display(Name = "Оклад")]
        [DataType(DataType.Currency)]
        [Required(ErrorMessage = "Укажите оклад")]
        public decimal Salary { get; set; }

        [Display(Name = "Обязанности")]
        [DataType(DataType.MultilineText)]
        public string Responsibilities { get; set; }

        [Display(Name = "Примечание")]
        [DataType(DataType.MultilineText)]
        public string Note { get; set; }

        public virtual ICollection<Employee> Employees { get; set; }
    }
}
