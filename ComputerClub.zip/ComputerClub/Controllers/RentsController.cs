﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ComputerClub;

namespace ComputerClub.Controllers
{
    public class RentsController : Controller
    {
        private readonly ComputerContext _context;

        public RentsController(ComputerContext context)
        {
            _context = context;
        }

        // GET: Rents
        public async Task<IActionResult> Index(int id)
        {
            ViewBag.Admin = id;
            var computerContext = _context.Rents.Include(r => r.IdcomputerNavigation).Include(r => r.IdempNavigation).Include(r => r.RentClientNavigation);
            foreach (var computer in computerContext)
            {
                var freeComputer = await _context.Computers.FindAsync(computer.Idcomputer);
                if (computer.DateTimeEnd < DateTime.Now)
                {
                    freeComputer.IsFree = true;
                    _context.Computers.Update(freeComputer);
                }
                else
                {
                    freeComputer.IsFree = false;
                    _context.Computers.Update(freeComputer);
                }
            }
            await _context.SaveChangesAsync();
            ViewBag.Free = _context.Computers.Where(f => f.IsFree).Count();
            return View(await computerContext.ToListAsync());
        }

        // GET: Rents/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rent = await _context.Rents
                .Include(r => r.IdcomputerNavigation)
                .Include(r => r.IdempNavigation)
                .Include(r => r.RentClientNavigation)
                .FirstOrDefaultAsync(m => m.Idrent == id);
            if (rent == null)
            {
                return NotFound();
            }

            return View(rent);
        }

        // GET: Rents/Create
        public async Task<IActionResult> Create(int id, int idClient)
        {
            ViewBag.Admin = id;
            var client = _context.Clients.FindAsync(idClient);
            if (await client != null) ViewBag.nameClient = client.Result.Fio;
            else client.AsTask().Dispose();

            var computers = _context.Computers.Where(c => c.IsFree);
            ViewData["Idcomputer"] = new SelectList(computers, "Idcomputer", "Idcomputer");

            return View(new Rent {
                RentClient=idClient
            });
        }

        // POST: Rents/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Idrent,Idemp,RentClient,Idcomputer,Renter,DateTimeStart,DateTimeEnd,Price,Note")] Rent rent, int id)
        {
            if (ModelState.IsValid)
            {
                _context.Add(rent);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index), new { id });
            }
            ViewBag.Admin = id;
            var client = _context.Clients.FindAsync(rent.RentClient);

            if (await client != null) ViewBag.nameClient = client.Result.Fio;
            else client.AsTask().Dispose();

            var computers = _context.Computers.Where(c => c.IsFree);
            ViewData["Idcomputer"] = new SelectList(computers, "Idcomputer", "Idcomputer", rent.Idcomputer);
            return View(rent);
        }

        // GET: Rents/Edit/5
        public async Task<IActionResult> Edit(int? id, int idAdmin)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rent = await _context.Rents.FindAsync(id);
            if (rent == null)
            {
                return NotFound();
            }
            ViewBag.Admin = idAdmin;
            List<Computer> computers = await _context.Computers.Where(c => c.IsFree).ToListAsync();

            if(!computers.Contains(await _context.Computers.FindAsync(rent.Idcomputer)))
                computers.Add(await _context.Computers.FindAsync(rent.Idcomputer));

            ViewData["Idcomputer"] = new SelectList(computers, "Idcomputer", "Idcomputer", rent.Idcomputer);
            var admin = _context.Employees.Where(p => p.IdpostNavigation.Postname.ToLower().Contains("ад"));
            ViewData["Idemp"] = new SelectList(admin, "Idemp", "Fio", rent.Idemp);
            return View(rent);
        }

        // POST: Rents/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Idrent,Idemp,RentClient,Idcomputer,Renter,DateTimeStart,DateTimeEnd,Price,Note")] Rent rent, int idAdmin)
        {
            if (id != rent.Idrent)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(rent);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RentExists(rent.Idrent))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index), new { id = idAdmin });
            }
            ViewBag.Admin = idAdmin;
            List<Computer> computers = await _context.Computers.Where(c => c.IsFree).ToListAsync();

            if (!computers.Contains(await _context.Computers.FindAsync(rent.Idcomputer)))
                computers.Add(await _context.Computers.FindAsync(rent.Idcomputer));

            ViewData["Idcomputer"] = new SelectList(computers, "Idcomputer", "Idcomputer", rent.Idcomputer);
            var admin = _context.Employees.Where(p => p.IdpostNavigation.Postname.ToLower().Contains("ад"));
            ViewData["Idemp"] = new SelectList(admin, "Idemp", "Fio", rent.Idemp);
            return View(rent);
        }

        // GET: Rents/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rent = await _context.Rents
                .Include(r => r.IdcomputerNavigation)
                .Include(r => r.IdempNavigation)
                .Include(r => r.RentClientNavigation)
                .FirstOrDefaultAsync(m => m.Idrent == id);
            if (rent == null)
            {
                return NotFound();
            }

            return View(rent);
        }

        // POST: Rents/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var rent = await _context.Rents.FindAsync(id);
            _context.Rents.Remove(rent);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool RentExists(int id)
        {
            return _context.Rents.Any(e => e.Idrent == id);
        }
    }
}
