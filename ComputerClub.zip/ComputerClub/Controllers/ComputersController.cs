﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ComputerClub;

namespace ComputerClub.Controllers
{
    public class ComputersController : Controller
    {
        private readonly ComputerContext _context;

        public ComputersController(ComputerContext context)
        {
            _context = context;
        }

        // GET: Computers
        public async Task<IActionResult> Index(int id)
        {
            ViewBag.Post = _context.Employees.Where(i => i.Idemp == id).Select(p => p.IdpostNavigation.Postname).First().ToLower();
            ViewBag.idEmp = id;
            return View(await _context.Computers.ToListAsync());
        }

        //Метод, к которому мы обращаемся из Rents/Create
        // GET: Computers/Details/5
        public async Task<Computer> Details(int? id)
        {
            return await _context.Computers.FindAsync(id);
        }

        // GET: Computers/Create
        public IActionResult Create(int id)
        {
            ViewBag.idEmp = id;
            ViewBag.OS = new SelectList(new List<string>
            {
                "Windows",
                "MacOs",
                "Linux"
            });
            ViewBag.Type = new SelectList(new List<string>
            {
                "Игровой",
                "Для работы"
            });
            return View();
        }

        // POST: Computers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Idcomputer,Os,Type,Price,IsFree,Note")] Computer computer, int id)
        {
            if (ModelState.IsValid)
            {
                _context.Add(computer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index), new { id });
            }
            ViewBag.idEmp = id;
            ViewBag.OS = new SelectList(new List<string>
            {
                "Windows",
                "MacOs",
                "Linux"
            });
            ViewBag.Type = new SelectList(new List<string>
            {
                "Игровой",
                "Для работы"
            });
            return View(computer);
        }

        // GET: Computers/Edit/5
        public async Task<IActionResult> Edit(int? id, int idTech)
        {
            if (id == null)
            {
                return NotFound();
            }

            var computer = await _context.Computers.FindAsync(id);
            if (computer == null)
            {
                return NotFound();
            }
            ViewBag.idEmp = idTech;
            ViewBag.OS = new SelectList(new List<string>
            {
                "Windows",
                "MacOs",
                "Linux"
            });
            ViewBag.Type = new SelectList(new List<string>
            {
                "Игровой",
                "Для работы"
            });
            return View(computer);
        }

        // POST: Computers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Idcomputer,Os,Type,Price,IsFree,Note")] Computer computer, int idTech)
        {
            if (id != computer.Idcomputer)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(computer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ComputerExists(computer.Idcomputer))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index), new { id = idTech });
            }
            ViewBag.idEmp = idTech;
            ViewBag.OS = new SelectList(new List<string>
            {
                "Windows",
                "MacOs",
                "Linux"
            });
            ViewBag.Type = new SelectList(new List<string>
            {
                "Игровой",
                "Для работы"
            });
            return View(computer);
        }

        // GET: Computers/Delete/5
        public async Task<IActionResult> Delete(int? id, int idTech)
        {
            ViewBag.idEmp = idTech;
            if (id == null)
            {
                return NotFound();
            }

            var computer = await _context.Computers
                .FirstOrDefaultAsync(m => m.Idcomputer == id);
            if (computer == null)
            {
                return NotFound();
            }
            ViewBag.idEmp = idTech;
            return View(computer);
        }

        // POST: Computers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id, int idTech)
        {
            var computer = await _context.Computers.FindAsync(id);
            _context.Computers.Remove(computer);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index), new { id = idTech });
        }

        private bool ComputerExists(int id)
        {
            return _context.Computers.Any(e => e.Idcomputer == id);
        }
    }
}
