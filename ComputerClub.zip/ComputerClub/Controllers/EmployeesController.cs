﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ComputerClub;

namespace ComputerClub.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly ComputerContext _context;

        public EmployeesController(ComputerContext context)
        {
            _context = context;
        }

        // GET: Employees
        public async Task<IActionResult> Index()
        {
            ViewBag.Dir = _context.Employees.Where(d => d.IdpostNavigation.Postname.ToLower() == "директор").Select(i => i.Idemp).First();
            var computerContext = _context.Employees.Include(e => e.IdpostNavigation);
            return View(await computerContext.ToListAsync());
        }

        public async Task<IActionResult> LK(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .Include(e => e.IdpostNavigation)
                .FirstOrDefaultAsync(m => m.Idemp == id);
            //шифровка пароля
            string pass = null;
            foreach (var s in employee.Password)
                pass += '*';
            employee.Password = pass;
            //полное наименование пола
            if (employee.Gender.ToUpper() == "М")
                employee.Gender = "Мужской";
            else employee.Gender = "Женский";
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        // GET: Employees/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .Include(e => e.IdpostNavigation)
                .FirstOrDefaultAsync(m => m.Idemp == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // GET: Employees/Create
        public IActionResult Create()
        {
            ViewData["Idpost"] = new SelectList(_context.Posts, "Idpost", "Postname");
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Idemp,Login,Password,Idpost,Fio,Gender,Birthday,PassportSeria,PassportNumber,Adress,Telephon,Note")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                _context.Add(employee);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["Idpost"] = new SelectList(_context.Posts, "Idpost", "Postname", employee.Idpost);
            return View(employee);
        }

        // GET: Employees/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            ViewData["Idpost"] = new SelectList(_context.Posts, "Idpost", "Postname", employee.Idpost);
            return View(employee);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Idemp,Login,Password,Idpost,Fio,Gender,Birthday,PassportSeria,PassportNumber,Adress,Telephon,Note")] Employee employee)
        {
            if (id != employee.Idemp)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employee);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeExists(employee.Idemp))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(LK), new { id = employee.Idemp });
            }
            ViewData["Idpost"] = new SelectList(_context.Posts, "Idpost", "Postname", employee.Idpost);
            return View(employee);
        }

        // GET: Employees/EditEmp/5
        public async Task<IActionResult> EditEmp(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            ViewData["Idpost"] = new SelectList(_context.Posts, "Idpost", "Postname", employee.Idpost);
            return View(employee);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditEmp(int id, [Bind("Idemp,Login,Password,Idpost,Fio,Birthday,Gender,Adress,Telephon,PassportSeria,PassportNumber,Note")] Employee employee)
        {
            if (id != employee.Idemp)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employee);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeExists(employee.Idemp))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["Idpost"] = new SelectList(_context.Posts, "Idpost", "Postname", employee.Idpost);
            return View(employee);
        }

        // GET: Employees/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .Include(e => e.IdpostNavigation)
                .FirstOrDefaultAsync(m => m.Idemp == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeExists(int id)
        {
            return _context.Employees.Any(e => e.Idemp == id);
        }
    }
}
